/** Pure review policy. Scene schemas, geometry, storage and approval stay with their source owners. */
export declare const SPATIAL_REVIEW_MAX_BYTES: number;
export declare const SPATIAL_REVIEW_MAX_RECEIPTS = 32;
export declare class SpatialReviewError extends Error {
    code: string;
    constructor(code: string, message: string);
}
export declare function refuse(code: string, message: string): never;
export declare function canonicalSpatialJson(value: unknown): string;
export declare function spatialDigest(value: unknown): Promise<string>;
export declare function freezeSpatial<T>(value: T): T;
export declare function enforceSpatialBudget(value: unknown): void;
export declare function spatialValuesEqual(before: unknown, after: unknown): boolean;
export type SpatialCapability = 'inspect' | 'preview' | 'apply' | 'undo' | 'export';
export type SpatialSourceDescriptor = Readonly<{
    sourceKind: string;
    schema: string;
    documentId: string;
    session: string;
    revision: string;
}>;
export type SpatialSourceIdentity = SpatialSourceDescriptor & Readonly<{
    token: string;
}>;
export type SpatialSourceBinding = Readonly<{
    sourceKind: string;
    schema: string;
    sourceToken: string;
}>;
/** The owner supplies its persisted revision and local session; this token grants no write authority. */
export declare function createSpatialSourceIdentity(source: SpatialSourceDescriptor): Promise<SpatialSourceIdentity>;
/** Validate an untrusted binding against a freshly inspected identity and owner-selected capabilities. */
export declare function requireSpatialCapability(current: SpatialSourceIdentity, binding: unknown, operation: string, supported: readonly SpatialCapability[]): void;
